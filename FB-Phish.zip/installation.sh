git
php7
python3

awebserver app
free-url-shortener