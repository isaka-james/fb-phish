#!bin/bash
# made by masterplan777
# For more cool tricks www.youtube.com/@masterplan777

watch -n 2 "cat backend/data.txt && echo 'Waiting...'"